"""Regression tests for three reported gate/offer defects.

1. SubGram «Проверить» never passed: statuses the provider itself calls
   unverifiable (``notgetted``) and resource types Telegram membership cannot be
   checked (``resource``, ``smart_link``) were treated as blocking, so «Я
   подписался» looped forever. A provider that blocks without giving any tappable
   link is a dead end too and must not hold the cascade.
2. BotoHub / PiarFlow / Flyer never produced a single task: the first provider in
   the list was allowed to consume the whole limit, and offers the provider already
   marked ``done`` (the mandatory subs the user had just completed) filled the
   screen instead of real work.
3. The first ``/start`` demanded the entire cascade before showing anything.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from app.bot.texts import BRAND
from app.config import Settings
from app.db.models import User
from app.op.base import OpContext, OpResult, PartnerOffer, Sponsor
from app.op.gate import OpGate
from app.op.subgram import SubGramAdapter
from app.services import partner_tasks as partner_service
from app.services.onboarding import begin_intro, intro_active, intro_limit
from tests.conftest import USER_ID
from tests.fake_telegram import callback_update, message_update


def _settings(**overrides) -> Settings:
    return Settings(admin_ids_raw="1", database_url="sqlite+aiosqlite://", **overrides)


def _ctx(user_id: int = 1) -> OpContext:
    return OpContext(user_id, user_id, "Даниил", "daniel", "ru", False)


# --- 1. SubGram gate ---------------------------------------------------------------


def _sponsor(status: str, *, type_: str = "channel", available: bool = True, link: str = "https://t.me/a"):
    return {
        "resource_id": link,
        "link": link,
        "resource_name": "Канал",
        "button_text": "Подписаться",
        "type": type_,
        "status": status,
        "available_now": available,
    }


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("sponsors", "should_pass"),
    [
        ([_sponsor("subscribed")], True),
        # «не удалось проверить» — SubGram's own wording. Must not trap the user.
        ([_sponsor("notgetted")], True),
        # Non-checkable resource types are never reported as subscribed.
        ([_sponsor("unsubscribed", type_="resource")], True),
        ([_sponsor("unsubscribed", type_="smart_link")], True),
        # Stopped / rejected by moderation: docs say do not show it at all.
        ([_sponsor("unsubscribed", available=False)], True),
        # A genuine pending subscription still blocks.
        ([_sponsor("unsubscribed")], False),
    ],
)
async def test_subgram_only_blocks_on_a_real_pending_subscription(
    monkeypatch, sponsors, should_pass
) -> None:
    settings = _settings(subgram_api_key="key")
    adapter = SubGramAdapter(settings)

    async def fake_post(url, *, json, headers=None, timeout_sec=8.0):
        return 200, {"status": "warning", "additional": {"sponsors": sponsors}}

    monkeypatch.setattr("app.op.subgram.post_json", fake_post)
    result = await adapter.check(_ctx())
    assert result.allowed is should_pass
    if not should_pass:
        assert [s.url for s in result.sponsors] == ["https://t.me/a"]


@pytest.mark.asyncio
async def test_subgram_verify_accepts_unverifiable_rows(monkeypatch) -> None:
    """The «Я подписался» round trip must end, even when SubGram cannot confirm."""
    settings = _settings(subgram_api_key="key")
    adapter = SubGramAdapter(settings)
    calls: list[str] = []

    async def fake_post(url, *, json, headers=None, timeout_sec=8.0):
        calls.append(url)
        if url.endswith("/get-sponsors"):
            return 200, {"status": "warning", "additional": {"sponsors": [_sponsor("unsubscribed")]}}
        # Bare top-level list, as the real endpoint answers.
        return 200, [_sponsor("notgetted")]

    monkeypatch.setattr("app.op.subgram.post_json", fake_post)
    assert (await adapter.check(_ctx())).allowed is False
    assert (await adapter.verify(_ctx())).allowed is True
    assert any(url.endswith("/get-user-subscriptions") for url in calls)


@pytest.mark.asyncio
async def test_gate_does_not_stop_on_a_provider_without_links(session) -> None:
    """Blocked + no sponsors + no self-served message = dead end; move on."""

    class Mute:
        name = "subgram"

        async def check(self, ctx):
            return OpResult.blocked(self.name, [], "нужна подписка")

        verify = check

    class Loud:
        name = "manual"

        async def check(self, ctx):
            return OpResult.blocked(self.name, [Sponsor(title="Наш", url="https://t.me/own")])

        verify = check

    settings = _settings(manual_op_channels="@own")
    passing = OpGate(settings, adapters=[Mute()])
    assert (await passing.enforce(_ctx(), session, settings=settings)).allowed is True

    # A provider that *does* give a link still blocks.
    blocking = OpGate(settings, adapters=[Mute(), Loud()])
    result = await blocking.enforce(_ctx(), session, settings=settings)
    assert result.allowed is False and result.provider == "manual"


@pytest.mark.asyncio
async def test_self_served_block_is_respected(session) -> None:
    """Flyer sends its own sponsor message: empty sponsors is still a real block."""

    class Flyer:
        name = "flyer"

        async def check(self, ctx):
            return OpResult.blocked(self.name, [], "см. сообщение выше", self_served=True)

        verify = check

    settings = _settings()
    gate = OpGate(settings, adapters=[Flyer()])
    assert (await gate.enforce(_ctx(), session, settings=settings)).allowed is False


# --- 2. Offers from every provider -------------------------------------------------


class _Provider:
    """Offer source with a configurable inventory."""

    def __init__(self, name: str, count: int, *, done: bool = False) -> None:
        self.name = name
        self._count = count
        self._done = done
        self.asked: list[int] = []

    async def check(self, ctx):
        return OpResult.ok(self.name)

    verify = check

    async def offers(self, ctx, limit: int) -> list[PartnerOffer]:
        self.asked.append(limit)
        return [
            PartnerOffer(
                external_id=f"{self.name}-{i}",
                title=f"{self.name} #{i}",
                url=f"https://t.me/{self.name}{i}",
                kind="channel",
                provider=self.name,
                done=self._done,
            )
            for i in range(self._count)
        ]

    async def confirm(self, ctx, offer):
        return True


@pytest.mark.asyncio
async def test_every_provider_gets_a_slice_of_the_limit(session) -> None:
    """A greedy first provider must not starve the others."""
    greedy = _Provider("flyer", 50)
    others = [_Provider(name, 3) for name in ("subgram", "botohub", "piarflow", "tgrass", "trafsly")]
    settings = _settings(
        flyer_api_key="k",
        subgram_api_key="k",
        botohub_api_key="k",
        piarflow_api_key="k",
        tgrass_api_key="k",
        trafsly_api_key="k",
    )
    gate = OpGate(settings, adapters=[greedy, *others])

    offers = await gate.collect_offers(_ctx(), session, limit=12, settings=settings)

    assert len(offers) == 12
    providers = {offer.provider for offer in offers}
    assert providers == {"flyer", "subgram", "botohub", "piarflow", "tgrass", "trafsly"}
    # Nobody was asked for the whole budget.
    assert greedy.asked == [2]


@pytest.mark.asyncio
async def test_already_completed_offers_are_not_shown(session) -> None:
    """The mandatory subs the user just finished are not «tasks»."""
    settings = _settings(flyer_api_key="k", subgram_api_key="k")
    gate = OpGate(
        settings,
        adapters=[_Provider("flyer", 5, done=True), _Provider("subgram", 2)],
    )
    offers = await gate.collect_offers(_ctx(), session, limit=10, settings=settings)
    assert [offer.provider for offer in offers] == ["subgram", "subgram"]


@pytest.mark.asyncio
async def test_spare_capacity_is_redistributed(session) -> None:
    """Providers with little inventory hand their share back to the others."""
    settings = _settings(flyer_api_key="k", subgram_api_key="k")
    gate = OpGate(settings, adapters=[_Provider("flyer", 10), _Provider("subgram", 1)])
    offers = await gate.collect_offers(_ctx(), session, limit=8, settings=settings)
    assert len(offers) == 8
    assert sum(1 for o in offers if o.provider == "subgram") == 1


@pytest.mark.asyncio
async def test_list_offers_surfaces_all_providers(session) -> None:
    """End to end through the service the «Задания партнёров» screen uses."""
    settings = _settings(
        partner_tasks_limit=9,
        flyer_api_key="k",
        botohub_api_key="k",
        piarflow_api_key="k",
    )
    gate = OpGate(
        settings,
        adapters=[_Provider("flyer", 9), _Provider("botohub", 9), _Provider("piarflow", 9)],
    )
    user = User(id=900, first_name="U")
    session.add(user)
    await session.flush()

    views = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
    by_provider = {view.offer.provider for view in views}
    assert by_provider == {"flyer", "botohub", "piarflow"}
    assert all(view.reward > 0 for view in views)


# --- 3. Soft onboarding ------------------------------------------------------------


@pytest.mark.asyncio
async def test_first_start_shows_a_short_block_then_opens_the_bot(session) -> None:
    settings = _settings(op_intro_sponsors=2, op_intro_grace_sec=3600)
    user = User(id=901, first_name="U")
    session.add(user)
    await session.flush()

    # A newcomer is shown at most two sponsors...
    assert intro_limit(user, settings) == 2
    assert begin_intro(user, settings) is True
    assert intro_active(user, settings) is True
    # ...and the window opens only once.
    assert begin_intro(user, settings) is False


@pytest.mark.asyncio
async def test_full_cascade_returns_after_the_grace_window(session) -> None:
    settings = _settings(op_intro_sponsors=2, op_intro_grace_sec=60)
    user = User(id=902, first_name="U", op_intro_at=datetime.now(UTC) - timedelta(seconds=120))
    session.add(user)
    await session.flush()

    assert intro_active(user, settings) is False
    assert intro_limit(user, settings) == 0  # no trimming: show every sponsor


@pytest.mark.asyncio
async def test_intro_can_be_switched_off(session) -> None:
    settings = _settings(op_intro_enabled=False)
    user = User(id=903, first_name="U")
    session.add(user)
    await session.flush()
    assert intro_limit(user, settings) == 0
    assert begin_intro(user, settings) is False
    assert intro_active(user, settings) is False


@pytest.mark.asyncio
async def test_enforce_trims_the_sponsor_block(session) -> None:
    class Many:
        name = "manual"

        async def check(self, ctx):
            return OpResult.blocked(
                self.name,
                [Sponsor(title=f"Канал {i}", url=f"https://t.me/c{i}") for i in range(6)],
            )

        verify = check

    settings = _settings(manual_op_channels="@a")
    gate = OpGate(settings, adapters=[Many()])

    full = await gate.enforce(_ctx(), session, settings=settings)
    assert len(full.sponsors) == 6

    trimmed = await gate.enforce(_ctx(), session, settings=settings, max_sponsors=2)
    assert len(trimmed.sponsors) == 2


# --- 3b. Soft onboarding end to end ------------------------------------------------


@pytest.mark.asyncio(loop_scope="session")
async def test_first_start_opens_the_bot_end_to_end(harness) -> None:
    """The reported flow: a newcomer must see the menu without grinding the cascade."""
    h = harness
    await h.reset()
    h.settings.op_intro_enabled = True
    h.settings.op_intro_sponsors = 2
    h.settings.op_intro_grace_sec = 3600
    h.store.invalidate()
    try:
        # Not subscribed to the mandatory channel.
        h.tg.member_status[("@kodo", USER_ID)] = "left"
        await h.feed(message_update(USER_ID, "/start"))

        # A short welcome block, and the main menu right after it.
        texts_sent = h.tg.texts(USER_ID)
        assert "Добро пожаловать" in texts_sent[0]
        assert BRAND in texts_sent[-1], "the bot must open on the first /start"

        # And the rest of the bot is usable during the grace window.
        await h.feed(callback_update(USER_ID, "menu:daily"))
        assert "Обязательная подписка" not in h.tg.last_text(USER_ID)
    finally:
        h.settings.op_intro_enabled = False
        h.store.invalidate()
        await h.reset()
