"""Rewarded partner offers: adapter contracts, the gate aggregator and the payout."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

from app.config import Settings
from app.db.models import LedgerKind, PartnerTaskClaim, PartnerTaskStatus, User
from app.op import botohub, flyer, piarflow, subgram, tgrass, trafsly
from app.op.base import OpContext, OpResult, PartnerOffer
from app.op.botohub import BotoHubAdapter
from app.op.flyer import FlyerAdapter
from app.op.gate import OpGate
from app.op.piarflow import PiarFlowAdapter
from app.op.subgram import SubGramAdapter
from app.op.tgrass import TGrassAdapter
from app.op.trafsly import TrafslyAdapter
from app.services import ledger
from app.services import partner_tasks as partner_service
from app.services.errors import AlreadyClaimed, EconomyError

Responder = Callable[[str, dict[str, Any], dict[str, str] | None], tuple[int, Any]]


class FakeHttp:
    def __init__(self, responder: Responder) -> None:
        self.responder = responder
        self.calls: list[tuple[str, dict[str, Any], dict[str, str] | None]] = []

    async def __call__(self, url: str, *, json: dict[str, Any], headers=None, timeout_sec: float = 8.0):
        self.calls.append((url, json, headers))
        return self.responder(url, json, headers)

    def urls(self) -> list[str]:
        return [url for url, _, _ in self.calls]


def _ctx(user_id: int = 1) -> OpContext:
    return OpContext(user_id, user_id, "Даниил", "daniel", "ru", True)


def _settings(**overrides) -> Settings:
    return Settings(admin_ids_raw="1", database_url="sqlite+aiosqlite://", **overrides)


async def _user(session, user_id: int, **fields) -> User:
    user = User(id=user_id, first_name=f"U{user_id}", **fields)
    session.add(user)
    await session.flush()
    return user


# --- adapters --------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_flyer_offers_and_confirm(monkeypatch) -> None:
    tasks = [
        {
            "signature": "sig-1",
            "task": "subscribe channel",
            "links": ["https://t.me/first"],
            "name": "First",
            "status": "incomplete",
        },
        {
            "signature": "sig-2",
            "task": "start bot",
            "links": ["https://t.me/bot?start=x"],
            "status": "complete",
        },
        {"signature": "sig-3", "task": "subscribe channel", "links": [], "status": "incomplete"},
        {"signature": "sig-4", "task": "follow link", "links": ["https://x.y"], "status": "unavailable"},
    ]

    def responder(url, body, headers):
        if url.endswith("/get_me"):
            return 200, {"type": "tasks"}
        if url.endswith("/get_tasks"):
            return 200, {"result": tasks}
        if url.endswith("/check_task"):
            return 200, {"result": {"status": "complete"}}
        raise AssertionError(url)

    monkeypatch.setattr(flyer, "post_json", FakeHttp(responder))
    adapter = FlyerAdapter(_settings(flyer_api_key="FL"))
    offers = await adapter.offers(_ctx(), 10)
    # Broken (no link) and stale (`unavailable`) entries are dropped.
    assert [(o.external_id, o.kind, o.done) for o in offers] == [
        ("sig-1", "channel", False),
        ("sig-2", "bot", True),
    ]
    assert await adapter.confirm(_ctx(), offers[0]) is True


@pytest.mark.asyncio
async def test_flyer_sub_key_serves_no_offers(monkeypatch) -> None:
    def responder(url, body, headers):
        if url.endswith("/get_me"):
            return 200, {"type": "sub"}
        raise AssertionError(url)

    monkeypatch.setattr(flyer, "post_json", FakeHttp(responder))
    assert await FlyerAdapter(_settings(flyer_api_key="FL")).offers(_ctx(), 5) == []


@pytest.mark.asyncio
async def test_subgram_offers_use_newtask_action(monkeypatch) -> None:
    http = FakeHttp(
        lambda url, body, headers: (
            200,
            {
                "status": "warning",
                "additional": {
                    "sponsors": [
                        {
                            "resource_id": 11,
                            "link": "https://t.me/sg",
                            "resource_name": "SG",
                            "type": "channel",
                            "status": "unsubscribed",
                        }
                    ]
                },
            },
        )
        if url.endswith("/get-sponsors")
        else (200, [{"link": "https://t.me/sg", "status": "subscribed"}])
    )
    monkeypatch.setattr(subgram, "post_json", http)
    adapter = SubGramAdapter(_settings(subgram_api_key="SG"))
    offers = await adapter.offers(_ctx(), 5)
    assert [(o.external_id, o.title) for o in offers] == [("11", "SG")]
    assert http.calls[0][1]["action"] == "newtask"
    assert await adapter.confirm(_ctx(), offers[0]) is True


@pytest.mark.asyncio
async def test_botohub_offers_and_confirm(monkeypatch) -> None:
    state = {
        "tasks": [
            {"url": "https://t.me/bh", "resource_id": 5, "completed": False},
            {"url": "https://t.me/done", "resource_id": 6, "completed": True},
        ]
    }
    monkeypatch.setattr(botohub, "post_json", FakeHttp(lambda url, body, headers: (200, state)))
    adapter = BotoHubAdapter(_settings(botohub_api_key="BH"))
    offers = await adapter.offers(_ctx(), 5)
    assert [(o.external_id, o.done) for o in offers] == [("5", False), ("6", True)]
    assert await adapter.confirm(_ctx(), offers[0]) is False
    state["tasks"][0]["completed"] = True
    assert await adapter.confirm(_ctx(), offers[0]) is True


@pytest.mark.asyncio
async def test_piarflow_and_tgrass_offers(monkeypatch) -> None:
    monkeypatch.setattr(
        piarflow,
        "post_json",
        FakeHttp(
            lambda url, body, headers: (
                200,
                {"sponsors": [{"link": "https://t.me/pf", "status": "unsubscribed", "price": 1}]},
            )
            if url.endswith("/sponsors")
            else (200, {"sponsors": [{"link": "https://t.me/pf", "status": "subscribed"}]})
        ),
    )
    pf = PiarFlowAdapter(_settings(piarflow_api_key="PF"))
    pf_offers = await pf.offers(_ctx(), 5)
    assert [o.external_id for o in pf_offers] == ["https://t.me/pf"]
    assert await pf.confirm(_ctx(), pf_offers[0]) is True

    offers_payload = {
        "status": "not_ok",
        "offers": [
            {"offer_id": 42, "link": "https://t.me/tg", "name": "TG", "type": "channel", "subscribed": False}
        ],
    }
    monkeypatch.setattr(tgrass, "post_json", FakeHttp(lambda url, body, headers: (200, offers_payload)))
    tg = TGrassAdapter(_settings(tgrass_api_key="TG"))
    tg_offers = await tg.offers(_ctx(), 5)
    assert [(o.external_id, o.title, o.done) for o in tg_offers] == [("42", "TG", False)]
    offers_payload["offers"][0]["subscribed"] = True
    assert await tg.confirm(_ctx(), tg_offers[0]) is True


@pytest.mark.asyncio
async def test_trafsly_offers_and_confirm(monkeypatch) -> None:
    confirmed = {"value": False}

    def responder(url, body, headers):
        if url.endswith("get-sponsors"):
            return 200, {
                "status": "warning",
                "sponsors": [
                    {
                        "ads_id": 77,
                        "link": "https://t.me/tf",
                        "title": "TF",
                        "resource_type": "channel",
                        "status": "unsubscribed",
                    }
                ],
            }
        return 200, {"subscribed": confirmed["value"], "message": "not subscribed"}

    monkeypatch.setattr(trafsly, "post_json", FakeHttp(responder))
    adapter = TrafslyAdapter(_settings(trafsly_api_key="TF"))
    offers = await adapter.offers(_ctx(), 5)
    assert [(o.external_id, o.meta["ads_id"]) for o in offers] == [("77", 77)]
    assert await adapter.confirm(_ctx(), offers[0]) is False
    confirmed["value"] = True
    assert await adapter.confirm(_ctx(), offers[0]) is True


@pytest.mark.asyncio
async def test_offer_adapters_are_silent_without_keys() -> None:
    settings = _settings()
    for adapter in (
        FlyerAdapter(settings),
        SubGramAdapter(settings),
        BotoHubAdapter(settings),
        PiarFlowAdapter(settings),
        TGrassAdapter(settings),
        TrafslyAdapter(settings),
    ):
        assert await adapter.offers(_ctx(), 5) == []


# --- gate aggregation -------------------------------------------------------------------


class StubOfferAdapter:
    def __init__(self, name: str, offers: list[PartnerOffer], *, boom: bool = False) -> None:
        self.name = name
        self._offers = offers
        self._boom = boom
        self.confirmed: list[str] = []

    async def check(self, user: OpContext):
        return OpResult.ok(self.name)

    async def verify(self, user: OpContext):
        return await self.check(user)

    async def offers(self, user: OpContext, limit: int) -> list[PartnerOffer]:
        if self._boom:
            raise RuntimeError("provider down")
        return self._offers[:limit]

    async def confirm(self, user: OpContext, offer: PartnerOffer) -> bool | None:
        self.confirmed.append(offer.external_id)
        return True


def _offer(provider: str, external_id: str, kind: str = "channel") -> PartnerOffer:
    return PartnerOffer(
        external_id=external_id,
        title=f"{provider}-{external_id}",
        url=f"https://t.me/{external_id}",
        kind=kind,
        provider=provider,
    )


@pytest.mark.asyncio
async def test_gate_collects_offers_and_survives_a_broken_provider(session) -> None:
    settings = _settings()
    good = StubOfferAdapter("flyer", [_offer("flyer", "a"), _offer("flyer", "b")])
    broken = StubOfferAdapter("subgram", [], boom=True)
    third = StubOfferAdapter("botohub", [_offer("botohub", "c", "bot")])
    gate = OpGate(settings, adapters=[good, broken, third])

    offers = await gate.collect_offers(_ctx(), session, limit=10, settings=settings)
    assert [(o.provider, o.external_id) for o in offers] == [
        ("flyer", "a"),
        ("flyer", "b"),
        ("botohub", "c"),
    ]
    # The limit is global across providers.
    assert len(await gate.collect_offers(_ctx(), session, limit=2, settings=settings)) == 2


@pytest.mark.asyncio
async def test_gate_skips_disabled_providers(session) -> None:
    settings = _settings(flyer_enabled=False)
    flyer_stub = StubOfferAdapter("flyer", [_offer("flyer", "a")])
    gate = OpGate(settings, adapters=[flyer_stub])
    assert await gate.collect_offers(_ctx(), session, limit=5, settings=settings) == []


# --- service: pricing, reservation, payout ------------------------------------------------


@pytest.mark.asyncio
async def test_offers_are_priced_by_kind_and_hidden_once_paid(session) -> None:
    settings = _settings(partner_reward_channel=3, partner_reward_bot=7)
    user = await _user(session, 900)
    adapter = StubOfferAdapter("flyer", [_offer("flyer", "a"), _offer("flyer", "b", "bot")])
    gate = OpGate(settings, adapters=[adapter])

    views = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
    assert [(v.offer.external_id, v.reward) for v in views] == [("a", 3), ("b", 7)]

    claim = await partner_service.reserve(session, user=user, offer=views[1].offer, settings=settings)
    amount = await partner_service.complete(
        session, user=user, claim=claim, gate=gate, settings=settings
    )
    assert amount == 7
    assert await ledger.get_balance(session, user.id) == 7

    # Paid offers disappear from the list and cannot be paid twice.
    left = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
    assert [v.offer.external_id for v in left] == ["a"]
    with pytest.raises(AlreadyClaimed):
        await partner_service.complete(session, user=user, claim=claim, gate=gate, settings=settings)


@pytest.mark.asyncio
async def test_reserve_is_idempotent_and_keeps_quoted_price(session) -> None:
    settings = _settings(partner_reward_channel=4)
    user = await _user(session, 901)
    adapter = StubOfferAdapter("flyer", [_offer("flyer", "a")])
    gate = OpGate(settings, adapters=[adapter])
    views = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)

    first = await partner_service.reserve(session, user=user, offer=views[0].offer, settings=settings)
    second = await partner_service.reserve(session, user=user, offer=views[0].offer, settings=settings)
    assert first.id == second.id

    # The rate drops, but the user was already quoted 4 ⭐.
    cheaper = _settings(partner_reward_channel=1)
    again = await partner_service.list_offers(session, user=user, gate=gate, settings=cheaper)
    assert again[0].reward == 4


@pytest.mark.asyncio
async def test_unconfirmed_offer_pays_nothing(session) -> None:
    settings = _settings()
    user = await _user(session, 902)

    class Refusing(StubOfferAdapter):
        async def confirm(self, user: OpContext, offer: PartnerOffer):
            return False

    class Silent(StubOfferAdapter):
        async def confirm(self, user: OpContext, offer: PartnerOffer):
            return None

    for adapter_cls, expected in ((Refusing, "не засчитано"), (Silent, "не отвечает")):
        adapter = adapter_cls("flyer", [_offer("flyer", f"x{expected}")])
        gate = OpGate(settings, adapters=[adapter])
        views = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
        claim = await partner_service.reserve(
            session, user=user, offer=views[0].offer, settings=settings
        )
        with pytest.raises(EconomyError) as exc:
            await partner_service.complete(
                session, user=user, claim=claim, gate=gate, settings=settings
            )
        assert expected in exc.value.message
        assert claim.status == PartnerTaskStatus.PENDING.value
    assert await ledger.get_balance(session, user.id) == 0


@pytest.mark.asyncio
async def test_payout_respects_level_and_boost_multipliers(session) -> None:
    settings = _settings(partner_reward_channel=10)
    user = await _user(session, 903, xp=5000)  # max level → ×2
    adapter = StubOfferAdapter("flyer", [_offer("flyer", "a")])
    gate = OpGate(settings, adapters=[adapter])
    views = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
    claim = await partner_service.reserve(session, user=user, offer=views[0].offer, settings=settings)
    amount = await partner_service.complete(
        session, user=user, claim=claim, gate=gate, settings=settings
    )
    assert amount == 20

    entries = await ledger.history(session, user.id)
    assert entries[0].kind == LedgerKind.PARTNER_TASK.value
    assert entries[0].extra["base"] == 10


@pytest.mark.asyncio
async def test_partner_tasks_can_be_switched_off(session) -> None:
    settings = _settings(partner_tasks_enabled=False)
    user = await _user(session, 904)
    gate = OpGate(settings, adapters=[StubOfferAdapter("flyer", [_offer("flyer", "a")])])
    assert await partner_service.list_offers(session, user=user, gate=gate, settings=settings) == []


@pytest.mark.asyncio
async def test_admin_payout_report(session) -> None:
    settings = _settings(partner_reward_channel=5)
    gate = OpGate(settings, adapters=[StubOfferAdapter("flyer", [_offer("flyer", "a")])])
    for user_id in (905, 906):
        user = await _user(session, user_id)
        views = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
        claim = await partner_service.reserve(
            session, user=user, offer=views[0].offer, settings=settings
        )
        await partner_service.complete(session, user=user, claim=claim, gate=gate, settings=settings)

    assert await partner_service.completed_count(session) == 2
    assert await partner_service.payout_by_provider(session) == [("flyer", 2, 10)]


@pytest.mark.asyncio
async def test_claim_round_trip_keeps_provider_tokens(session) -> None:
    claim = PartnerTaskClaim(
        user_id=1, provider="trafsly", external_id="77", kind="channel", title="T", url="https://t.me/t"
    )
    offer = partner_service.claim_to_offer(claim)
    assert offer.meta["ads_id"] == 77
    flyer_claim = PartnerTaskClaim(
        user_id=1, provider="flyer", external_id="sig", kind="bot", title="F", url="https://t.me/f"
    )
    assert partner_service.claim_to_offer(flyer_claim).meta["signature"] == "sig"
