"""The anti-spam cooldown must gate *rewarded* actions only.

Regression guard for a bug where the cooldown was measured against
``users.last_action_at`` — a column the user middleware refreshes on every single
update. With ``CLAIM_COOLDOWN_SECONDS > 0`` that made every claim fail forever with
«Слишком часто», because the timestamp was always a few milliseconds old.

Unlike the rest of the suite these tests deliberately run with the cooldown ON.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from app.config import Settings
from app.db.models import CampaignKind, User
from app.db.seed import seed_catalog
from app.op.base import OpContext, OpResult, PartnerOffer
from app.op.gate import OpGate
from app.services import campaigns as campaign_service
from app.services import daily, ledger, promo
from app.services import partner_tasks as partner_service
from app.services import tasks as task_service
from app.services.antifraud import bump_activity, ensure_action_cooldown
from app.services.errors import CooldownActive
from app.services.users import upsert_user


def _settings(**overrides) -> Settings:
    base = {
        "admin_ids_raw": "1",
        "database_url": "sqlite+aiosqlite://",
        "claim_cooldown_seconds": 3,
        "signup_bonus": 0,
    }
    return Settings(**{**base, **overrides})


async def _touch(session, settings, user_id: int = 700) -> User:
    """Simulate what UserMiddleware does on every incoming update."""
    user, _ = await upsert_user(
        session,
        telegram_id=user_id,
        username="u",
        first_name="U",
        language_code="ru",
        is_premium=False,
        settings=settings,
    )
    return user


@pytest.mark.asyncio
async def test_browsing_the_bot_does_not_start_the_cooldown(session) -> None:
    settings = _settings()
    user = await _touch(session, settings)
    # Several updates in a row (menu taps) — none of them is a reward.
    for _ in range(3):
        user = await _touch(session, settings)
    assert user.last_action_at is not None
    assert user.last_claim_at is None
    ensure_action_cooldown(user, settings)  # must not raise


@pytest.mark.asyncio
async def test_cooldown_starts_only_after_a_payout(session) -> None:
    settings = _settings()
    user = await _touch(session, settings)
    await bump_activity(session, user, 1)
    assert user.last_claim_at is not None

    # A later update refreshes "last seen" but must not extend the cooldown.
    user.last_claim_at = datetime.now(UTC) - timedelta(seconds=10)
    await _touch(session, settings)
    ensure_action_cooldown(user, settings)

    user.last_claim_at = datetime.now(UTC)
    with pytest.raises(CooldownActive) as exc:
        ensure_action_cooldown(user, settings)
    assert "Подождите" in exc.value.message


@pytest.mark.asyncio
async def test_task_claim_works_with_cooldown_enabled(session) -> None:
    """The original report: «проверка заданий вечно выбивает throttling»."""
    settings = _settings()
    await seed_catalog(session)
    user = await _touch(session, settings)
    task = await task_service.create_task(
        session, title="Ссылка", description="", kind="custom", reward=5, target="https://t.me/x"
    )
    # Fresh update right before pressing the button — exactly the broken scenario.
    user = await _touch(session, settings)
    _, amount = await task_service.claim_task(
        session, user=user, task_id=task.id, settings=settings
    )
    assert amount == 5
    assert await ledger.get_balance(session, user.id) == 5


@pytest.mark.asyncio
async def test_daily_and_promo_work_with_cooldown_enabled(session) -> None:
    settings = _settings(daily_base_reward=5)
    user = await _touch(session, settings)
    claim = await daily.claim_daily(session, user=user, settings=settings)
    assert claim.amount > 0

    code = await promo.create_promo(session, code="KODO", reward=7, max_uses=0, expires_at=None)
    other = await _touch(session, settings, user_id=701)
    _, amount = await promo.redeem(session, user=other, code=code.code, settings=settings)
    assert amount == 7


class _Stub:
    name = "flyer"

    async def check(self, user: OpContext) -> OpResult:
        return OpResult.ok(self.name)

    async def verify(self, user: OpContext) -> OpResult:
        return OpResult.ok(self.name)

    async def offers(self, user: OpContext, limit: int) -> list[PartnerOffer]:
        return [
            PartnerOffer(
                external_id="o1",
                title="Партнёр",
                url="https://t.me/p",
                kind="channel",
                provider=self.name,
            )
        ]

    async def confirm(self, user: OpContext, offer: PartnerOffer) -> bool:
        return True


@pytest.mark.asyncio
async def test_partner_task_and_campaign_work_with_cooldown_enabled(session) -> None:
    settings = _settings(campaign_moderation=False, campaign_min_target=1)
    gate = OpGate(settings, adapters=[_Stub()])

    user = await _touch(session, settings)
    views = await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
    claim = await partner_service.reserve(session, user=user, offer=views[0].offer, settings=settings)
    user = await _touch(session, settings)  # middleware runs again before «Проверить»
    amount = await partner_service.complete(
        session, user=user, claim=claim, gate=gate, settings=settings
    )
    assert amount == settings.partner_reward("channel")

    owner = await _touch(session, settings, user_id=702)
    campaign = await campaign_service.create_draft(
        session,
        owner=owner,
        kind=CampaignKind.POST.value,
        title="Мой пост",
        description="",
        target_raw="https://t.me/kodo/1",
        target_count=5,
        settings=settings,
    )
    await campaign_service.activate_paid(
        session, campaign=campaign, telegram_charge_id="ch-x", settings=settings
    )
    performer = await _touch(session, settings, user_id=703)
    paid = await campaign_service.complete(
        session, user=performer, campaign=campaign, settings=settings
    )
    assert paid == campaign.reward


@pytest.mark.asyncio
async def test_rapid_second_claim_is_still_rejected(session) -> None:
    """The cooldown must keep doing its actual job: blocking bursts of payouts."""
    settings = _settings()
    user = await _touch(session, settings)
    first = await task_service.create_task(
        session, title="Раз", description="", kind="custom", reward=3, target="https://t.me/a"
    )
    second = await task_service.create_task(
        session, title="Два", description="", kind="custom", reward=3, target="https://t.me/b"
    )
    await task_service.claim_task(session, user=user, task_id=first.id, settings=settings)
    with pytest.raises(CooldownActive):
        await task_service.claim_task(session, user=user, task_id=second.id, settings=settings)

    # Once the window passes, the next claim goes through.
    user.last_claim_at = datetime.now(UTC) - timedelta(seconds=settings.claim_cooldown_seconds + 1)
    _, amount = await task_service.claim_task(
        session, user=user, task_id=second.id, settings=settings
    )
    assert amount == 3
