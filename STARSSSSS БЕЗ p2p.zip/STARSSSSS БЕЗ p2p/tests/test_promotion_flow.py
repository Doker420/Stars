"""End-to-end: buying a promotion with Stars, moderation, and performing the task."""

import pytest
import pytest_asyncio
from aiogram.methods import SendInvoice
from sqlalchemy import select

from app.db.models import Campaign, CampaignStatus
from app.op.base import OpContext, OpResult, PartnerOffer
from app.services import ledger
from tests.conftest import ADMIN_ID, OTHER_ID, USER_ID, BotHarness
from tests.fake_telegram import (
    callback_update,
    message_update,
    pre_checkout_update,
    successful_payment_update,
)

pytestmark = pytest.mark.asyncio(loop_scope="session")


@pytest_asyncio.fixture(autouse=True, loop_scope="session")
async def _clean_state(harness: BotHarness) -> None:
    await harness.reset()


async def _start(h: BotHarness, user_id: int) -> None:
    await h.feed(message_update(user_id, "/start"))


async def _balance(h: BotHarness, user_id: int) -> int:
    async with h.factory() as session:
        return await ledger.get_balance(session, user_id)


async def _order_campaign(h: BotHarness, user_id: int, *, count: str = "10") -> Campaign:
    """Drive the whole advertiser wizard and pay the invoice."""
    await h.feed(callback_update(user_id, "menu:promote"))
    await h.feed(callback_update(user_id, "pr:new"))
    await h.feed(callback_update(user_id, "pr:kind:channel"))
    await h.feed(message_update(user_id, "Канал про Stars"))
    await h.feed(message_update(user_id, "@promoted"))
    await h.feed(message_update(user_id, "Лучший канал"))
    await h.feed(message_update(user_id, count))
    await h.feed(callback_update(user_id, "pr:pay"))

    async with h.factory() as session:
        campaign = (await session.execute(select(Campaign).order_by(Campaign.id.desc()))).scalars().first()
    assert campaign is not None

    invoice = h.tg.sent(SendInvoice)[-1]
    payload = invoice.payload
    await h.feed(pre_checkout_update(user_id, payload, invoice.prices[0].amount))
    await h.feed(
        successful_payment_update(user_id, payload, invoice.prices[0].amount, f"charge-{campaign.id}")
    )
    async with h.factory() as session:
        return await session.get(Campaign, campaign.id)


async def test_wizard_quotes_price_and_invoices_in_xtr(harness: BotHarness) -> None:
    h = harness
    await _start(h, USER_ID)
    await h.feed(callback_update(USER_ID, "menu:promote"))
    assert "Продвижение за Telegram Stars" in h.tg.last_text(USER_ID)

    await h.feed(callback_update(USER_ID, "pr:new"))
    await h.feed(callback_update(USER_ID, "pr:kind:channel"))
    assert "Шаг 2 из 5" in h.tg.last_text(USER_ID)

    await h.feed(message_update(USER_ID, "ab"))  # too short
    assert "от 3 символов" in h.tg.last_text(USER_ID)
    await h.feed(message_update(USER_ID, "Канал про Stars"))

    await h.feed(message_update(USER_ID, "не-канал"))  # bad target
    assert "⚠️" in h.tg.last_text(USER_ID)
    await h.feed(message_update(USER_ID, "@promoted"))
    await h.feed(message_update(USER_ID, "-"))  # skip description

    await h.feed(message_update(USER_ID, "много"))  # not a number
    assert "целое число" in h.tg.last_text(USER_ID)
    await h.feed(message_update(USER_ID, "50"))

    expected = h.settings.campaign_price("channel", 50)
    confirm = h.tg.last_text(USER_ID)
    assert "Проверь заказ" in confirm and f"{expected} XTR" in confirm

    await h.feed(callback_update(USER_ID, "pr:pay"))
    invoice = h.tg.sent(SendInvoice)[-1]
    assert invoice.currency == "XTR"
    assert invoice.prices[0].amount == expected


async def test_paid_campaign_goes_to_moderation_and_admin_approves(harness: BotHarness) -> None:
    h = harness
    await _start(h, USER_ID)
    campaign = await _order_campaign(h, USER_ID)
    assert campaign.status == CampaignStatus.MODERATION.value
    assert campaign.telegram_charge_id == f"charge-{campaign.id}"

    # The advertiser is told, the admin gets the moderation card.
    assert any("на модерацию" in text for text in h.tg.texts(USER_ID))
    assert any("Новая кампания на модерации" in text for text in h.tg.texts(ADMIN_ID))

    await h.feed(callback_update(ADMIN_ID, f"admin:camp:{campaign.id}:ok"))
    async with h.factory() as session:
        refreshed = await session.get(Campaign, campaign.id)
    assert refreshed.status == CampaignStatus.ACTIVE.value
    assert any("запущена" in text for text in h.tg.texts(USER_ID))


async def test_rejected_campaign_refunds_the_advertiser(harness: BotHarness) -> None:
    h = harness
    await _start(h, USER_ID)
    campaign = await _order_campaign(h, USER_ID)

    await h.feed(callback_update(ADMIN_ID, f"admin:camp:{campaign.id}:no"))
    assert "Причина отклонения" in h.tg.last_text(ADMIN_ID)
    await h.feed(message_update(ADMIN_ID, "Запрещённая тематика"))

    async with h.factory() as session:
        refreshed = await session.get(Campaign, campaign.id)
    assert refreshed.status == CampaignStatus.REJECTED.value
    assert refreshed.refunded_at is not None
    assert any("отклонена" in text for text in h.tg.texts(USER_ID))


async def test_performer_earns_from_an_active_campaign(harness: BotHarness) -> None:
    h = harness
    await _start(h, USER_ID)
    campaign = await _order_campaign(h, USER_ID)
    await h.feed(callback_update(ADMIN_ID, f"admin:camp:{campaign.id}:ok"))

    await _start(h, OTHER_ID)
    before = await _balance(h, OTHER_ID)
    await h.feed(callback_update(OTHER_ID, "menu:promotasks"))
    assert "Задания пользователей" in h.tg.last_text(OTHER_ID)

    await h.feed(callback_update(OTHER_ID, f"ct:view:{campaign.id}"))
    assert "Канал про Stars" in h.tg.last_text(OTHER_ID)

    # Not subscribed yet → no payout.
    h.tg.member_status[("@promoted", OTHER_ID)] = "left"
    await h.feed(callback_update(OTHER_ID, f"ct:do:{campaign.id}"))
    assert "Подписка ещё не найдена" in h.tg.alerts()[-1]
    assert await _balance(h, OTHER_ID) == before

    h.tg.member_status[("@promoted", OTHER_ID)] = "member"
    await h.feed(callback_update(OTHER_ID, f"ct:do:{campaign.id}"))
    assert await _balance(h, OTHER_ID) == before + campaign.reward

    # Second attempt pays nothing and the budget only moved by one.
    await h.feed(callback_update(OTHER_ID, f"ct:do:{campaign.id}"))
    assert await _balance(h, OTHER_ID) == before + campaign.reward
    async with h.factory() as session:
        refreshed = await session.get(Campaign, campaign.id)
    assert refreshed.done_count == 1


async def test_advertiser_can_pause_and_resume(harness: BotHarness) -> None:
    h = harness
    await _start(h, USER_ID)
    campaign = await _order_campaign(h, USER_ID)
    await h.feed(callback_update(ADMIN_ID, f"admin:camp:{campaign.id}:ok"))

    await h.feed(callback_update(USER_ID, f"pr:pause:{campaign.id}"))
    async with h.factory() as session:
        assert (await session.get(Campaign, campaign.id)).status == CampaignStatus.PAUSED.value

    # A paused campaign is invisible to performers.
    await _start(h, OTHER_ID)
    await h.feed(callback_update(OTHER_ID, "menu:promotasks"))
    assert "активных заказов нет" in h.tg.last_text(OTHER_ID)

    await h.feed(callback_update(USER_ID, f"pr:resume:{campaign.id}"))
    async with h.factory() as session:
        assert (await session.get(Campaign, campaign.id)).status == CampaignStatus.ACTIVE.value


async def test_foreign_user_cannot_touch_someone_elses_campaign(harness: BotHarness) -> None:
    h = harness
    await _start(h, USER_ID)
    campaign = await _order_campaign(h, USER_ID)
    await _start(h, OTHER_ID)

    await h.feed(callback_update(OTHER_ID, f"pr:view:{campaign.id}"))
    assert "не найдена" in h.tg.alerts()[-1]
    await h.feed(callback_update(OTHER_ID, f"pr:pause:{campaign.id}"))
    assert "не найдена" in h.tg.alerts()[-1]


# --- partner tasks through the dispatcher -------------------------------------------------


class StubOffers:
    """A fake monetization provider plugged into the live OpGate."""

    name = "flyer"

    def __init__(self) -> None:
        self.subscribed: set[str] = set()

    async def check(self, user: OpContext) -> OpResult:
        return OpResult.ok(self.name)

    async def verify(self, user: OpContext) -> OpResult:
        return OpResult.ok(self.name)

    async def offers(self, user: OpContext, limit: int) -> list[PartnerOffer]:
        return [
            PartnerOffer(
                external_id="offer-1",
                title="Канал партнёра",
                url="https://t.me/partner",
                kind="channel",
                provider=self.name,
            )
        ]

    async def confirm(self, user: OpContext, offer: PartnerOffer) -> bool | None:
        return offer.external_id in self.subscribed


async def test_partner_task_is_published_and_paid(harness: BotHarness, monkeypatch) -> None:
    h = harness
    stub = StubOffers()
    gate = h.dp.workflow_data["op_gate"]
    monkeypatch.setitem(gate.__dict__, "_by_name", {**gate.__dict__["_by_name"], "flyer": stub})
    monkeypatch.setattr(h.settings, "flyer_enabled", True)

    await _start(h, USER_ID)
    before = await _balance(h, USER_ID)

    await h.feed(callback_update(USER_ID, "menu:partner"))
    assert "Задания партнёров" in h.tg.last_text(USER_ID)
    assert "Канал партнёра" in str(h.tg.sent()[-1].reply_markup)

    await h.feed(callback_update(USER_ID, "pt:view:0"))
    assert "Канал партнёра" in h.tg.last_text(USER_ID)

    # Provider says "not done yet" → nothing is credited.
    await h.feed(callback_update(USER_ID, "pt:do:0"))
    assert "ещё не засчитано" in h.tg.alerts()[-1]
    assert await _balance(h, USER_ID) == before

    stub.subscribed.add("offer-1")
    await h.feed(callback_update(USER_ID, "pt:do:0"))
    expected = h.settings.partner_reward("channel")
    assert await _balance(h, USER_ID) == before + expected

    # The paid offer disappears from the refreshed list.
    await h.feed(callback_update(USER_ID, "menu:partner"))
    assert "нет доступных заданий" in h.tg.last_text(USER_ID)


async def test_partner_task_pays_only_once(harness: BotHarness, monkeypatch) -> None:
    h = harness
    stub = StubOffers()
    stub.subscribed.add("offer-1")
    gate = h.dp.workflow_data["op_gate"]
    monkeypatch.setitem(gate.__dict__, "_by_name", {**gate.__dict__["_by_name"], "flyer": stub})
    monkeypatch.setattr(h.settings, "flyer_enabled", True)

    await _start(h, USER_ID)
    before = await _balance(h, USER_ID)
    await h.feed(callback_update(USER_ID, "menu:partner"))
    await h.feed(callback_update(USER_ID, "pt:view:0"))
    await h.feed(callback_update(USER_ID, "pt:do:0"))
    paid = await _balance(h, USER_ID)
    assert paid == before + h.settings.partner_reward("channel")

    await h.feed(callback_update(USER_ID, "pt:do:0"))
    assert await _balance(h, USER_ID) == paid
