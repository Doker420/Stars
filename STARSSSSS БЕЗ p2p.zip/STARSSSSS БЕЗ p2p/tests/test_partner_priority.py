"""Partner offers are the monetized inventory and must stay visually first.

The project earns from partner tasks, so anything that quietly demotes them —
a reordered menu, a digest that forgets to count them, a header that buries the
line — is a revenue regression. These tests pin the ordering everywhere it is
user-visible, so a future refactor cannot silently undo it.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest
from aiogram.methods import SendMessage

from app.bot import keyboards, texts
from app.bot.factory import make_digest_sender
from app.config import Settings
from app.db.models import User
from app.op.base import OpContext, OpResult, PartnerOffer
from app.op.gate import OpGate
from app.services import partner_tasks as partner_service
from app.services import task_digest
from app.services import tasks as task_service
from app.services.task_digest import DigestPayload, TaskDigestRunner
from tests.conftest import USER_ID, BotHarness
from tests.fake_telegram import message_update

PARTNER_LABEL = "Задания партнёров"


def _settings(**overrides) -> Settings:
    base = {
        "admin_ids_raw": "1",
        "database_url": "sqlite+aiosqlite://",
        "task_digest_quiet_from": 0,
        "task_digest_quiet_to": 0,
    }
    return Settings(**{**base, **overrides})


def _labels(markup) -> list[str]:
    return [b.text for row in markup.inline_keyboard for b in row]


class _Provider:
    """Offer source with a fixed inventory."""

    name = "flyer"

    def __init__(self, count: int = 3) -> None:
        self._count = count

    async def check(self, ctx: OpContext) -> OpResult:
        return OpResult.ok(self.name)

    verify = check

    async def offers(self, ctx: OpContext, limit: int) -> list[PartnerOffer]:
        return [
            PartnerOffer(
                external_id=f"o{i}",
                title=f"Оффер {i}",
                url=f"https://t.me/o{i}",
                kind="channel",
                provider=self.name,
            )
            for i in range(min(self._count, limit))
        ]

    async def confirm(self, ctx: OpContext, offer: PartnerOffer) -> bool:
        return True


# --- menus -------------------------------------------------------------------------


def test_partner_offers_are_the_first_button_in_the_main_menu() -> None:
    labels = _labels(keyboards.main_menu())
    assert PARTNER_LABEL in labels[0], labels
    # Ahead of the non-monetized sections.
    assert labels.index(next(x for x in labels if PARTNER_LABEL in x)) < labels.index("📋 Задания")


def test_main_menu_shows_the_offer_count_when_known() -> None:
    assert "🤝 Задания партнёров (4)" in _labels(keyboards.main_menu(partner=4))
    # Unknown count degrades to the plain label rather than "(0)".
    assert "🤝 Задания партнёров" in _labels(keyboards.main_menu(partner=0))


def test_device_verification_still_outranks_everything() -> None:
    """A blocked user must fix verification first; that row stays on top."""
    labels = _labels(keyboards.main_menu(device_url="https://example.com/verify"))
    assert PARTNER_LABEL in labels[1]


def test_tasks_screen_lists_partner_offers_first() -> None:
    labels = _labels(keyboards.tasks_keyboard([], set(), partner=2, promo=5))
    assert PARTNER_LABEL in labels[0], labels


def test_tasks_header_puts_partner_line_above_the_rest() -> None:
    header = texts.tasks_header(done=1, total=4, partner=3, promo=2)
    assert header.index("От партнёров") < header.index("От пользователей")
    assert header.index("От партнёров") < header.index("Внутренние")


def test_digest_keyboard_leads_with_partner_offers() -> None:
    labels = _labels(keyboards.digest_keyboard(tasks=5, campaigns=5, partner=2))
    assert labels[0] == "🤝 Задания партнёров (2)"


def test_digest_text_leads_with_partner_offers() -> None:
    body = texts.task_digest(tasks=4, campaigns=3, partner=2)
    assert body.index("От партнёров") < body.index("Заданий доступно")
    assert body.index("От партнёров") < body.index("от пользователей")


# --- the digest actually counts them -----------------------------------------------


@pytest.mark.asyncio
async def test_digest_payload_counts_partner_offers(session) -> None:
    settings = _settings()
    gate = OpGate(settings, adapters=[_Provider(3)])
    user = User(id=500, first_name="U", started_at=datetime.now(UTC))
    session.add(user)
    await session.flush()

    payload = await task_digest.build_payload(session, user=user, settings=settings, gate=gate)
    assert payload.partner == 3
    assert payload.total == 3


@pytest.mark.asyncio
async def test_partner_only_user_still_gets_a_reminder(session_factory) -> None:
    """No internal tasks, no campaigns — the paid offers alone must trigger it."""
    settings = _settings()
    gate = OpGate(settings, adapters=[_Provider(2)])
    async with session_factory() as db:
        db.add(User(id=501, first_name="U", started_at=datetime.now(UTC)))
        await db.commit()

    sent: list[DigestPayload] = []

    async def sender(chat_id: int, payload: DigestPayload) -> None:
        sent.append(payload)

    runner = TaskDigestRunner(session_factory, sender=sender, settings=settings, gate=gate)
    assert await runner.run_once() == 1
    assert sent[0].partner == 2
    assert sent[0].tasks == 0


@pytest.mark.asyncio
async def test_provider_outage_does_not_break_the_reminder(session_factory) -> None:
    """A dead provider must not cost the user their other tasks."""

    class Broken:
        name = "flyer"

        async def check(self, ctx):
            return OpResult.ok(self.name)

        verify = check

        async def offers(self, ctx, limit):
            raise RuntimeError("provider down")

        async def confirm(self, ctx, offer):
            return None

    settings = _settings()
    gate = OpGate(settings, adapters=[Broken()])
    async with session_factory() as db:
        db.add(User(id=502, first_name="U", started_at=datetime.now(UTC)))
        await task_service.create_task(
            db, title="Внутреннее", description="", kind="custom", reward=5, target="https://t.me/x"
        )
        await db.commit()

    sent: list[DigestPayload] = []

    async def sender(chat_id: int, payload: DigestPayload) -> None:
        sent.append(payload)

    runner = TaskDigestRunner(session_factory, sender=sender, settings=settings, gate=gate)
    assert await runner.run_once() == 1
    assert sent[0].partner == 0
    assert sent[0].tasks == 1


@pytest.mark.asyncio
async def test_partner_counting_can_be_switched_off(session) -> None:
    """Escape hatch for provider quota: the rest of the digest keeps working."""
    settings = _settings(task_digest_include_partner=False)
    gate = OpGate(settings, adapters=[_Provider(5)])
    user = User(id=503, first_name="U", started_at=datetime.now(UTC))
    session.add(user)
    await session.flush()

    payload = await task_digest.build_payload(session, user=user, settings=settings, gate=gate)
    assert payload.partner == 0


# --- the menu badge ----------------------------------------------------------------


@pytest.mark.asyncio
async def test_menu_badge_tracks_the_last_real_fetch(session) -> None:
    settings = _settings()
    gate = OpGate(settings, adapters=[_Provider(3)])
    user = User(id=504, first_name="U")
    session.add(user)
    await session.flush()

    assert partner_service.cached_offer_count(user.id) == 0
    await partner_service.list_offers(session, user=user, gate=gate, settings=settings)
    assert partner_service.cached_offer_count(user.id) == 3

    # Disabling the feature clears the badge instead of leaving a stale number.
    off = _settings(partner_tasks_enabled=False)
    await partner_service.list_offers(session, user=user, gate=gate, settings=off)
    assert partner_service.cached_offer_count(user.id) == 0


# --- end to end ---------------------------------------------------------------------


@pytest.mark.asyncio(loop_scope="session")
async def test_reminder_message_puts_partner_offers_on_top(harness: BotHarness) -> None:
    h = harness
    await h.reset()
    await h.feed(message_update(USER_ID, "/start"))
    h.tg.clear()

    await make_digest_sender(h.bot)(USER_ID, DigestPayload(tasks=3, campaigns=2, partner=4))
    message = h.tg.sent(SendMessage)[-1]
    assert "От партнёров" in message.text
    labels = _labels(message.reply_markup)
    assert labels[0] == "🤝 Задания партнёров (4)"


@pytest.mark.asyncio(loop_scope="session")
async def test_main_menu_after_start_leads_with_partner_offers(harness: BotHarness) -> None:
    h = harness
    await h.reset()
    await h.feed(message_update(USER_ID, "/start"))
    message = h.tg.sent(SendMessage)[-1]
    assert PARTNER_LABEL in _labels(message.reply_markup)[0]
