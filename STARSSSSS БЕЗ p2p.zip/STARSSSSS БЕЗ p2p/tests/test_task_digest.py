"""Periodic "you have tasks waiting" reminders.

The risky part of any notification feature is not sending it — it is sending it
twice, at 4am, or to someone who asked you to stop. These tests pin that down.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from aiogram.exceptions import TelegramForbiddenError
from aiogram.methods import SendMessage

from app.bot.factory import make_digest_sender
from app.bot.texts import BRAND
from app.config import Settings
from app.db.models import Campaign, CampaignStatus, Task, User, UserTask
from app.services import task_digest
from app.services import tasks as task_service
from app.services.task_digest import DigestPayload, TaskDigestRunner, due_users, quiet_now
from tests.conftest import USER_ID, BotHarness
from tests.fake_telegram import callback_update, message_update


def _settings(**overrides) -> Settings:
    base = {
        "admin_ids_raw": "1",
        "database_url": "sqlite+aiosqlite://",
        "task_digest_interval_hours": 12,
        "task_digest_quiet_from": 0,
        "task_digest_quiet_to": 0,  # quiet hours off unless a test enables them
    }
    return Settings(**{**base, **overrides})


async def _user(session, user_id: int, **fields) -> User:
    defaults = {"first_name": f"U{user_id}", "started_at": datetime.now(UTC)}
    user = User(id=user_id, **{**defaults, **fields})
    session.add(user)
    await session.flush()
    return user


async def _task(session, title: str = "Подписка") -> Task:
    return await task_service.create_task(
        session, title=title, description="", kind="custom", reward=5, target="https://t.me/x"
    )


# --- quiet hours -------------------------------------------------------------------


@pytest.mark.parametrize(
    ("hour", "quiet"),
    [(23, True), (2, True), (8, True), (9, False), (12, False), (22, False)],
)
def test_quiet_hours_wrap_midnight(hour: int, quiet: bool) -> None:
    settings = _settings(task_digest_quiet_from=23, task_digest_quiet_to=9)
    now = datetime(2026, 9, 18, hour, tzinfo=UTC)
    assert quiet_now(settings, now=now) is quiet


def test_quiet_hours_can_be_disabled() -> None:
    settings = _settings(task_digest_quiet_from=0, task_digest_quiet_to=0)
    assert quiet_now(settings, now=datetime(2026, 9, 18, 3, tzinfo=UTC)) is False


# --- audience ----------------------------------------------------------------------


@pytest.mark.asyncio
async def test_due_users_respects_optout_bans_and_interval(session) -> None:
    settings = _settings()
    now = datetime.now(UTC)

    wanted = await _user(session, 1, last_task_digest_at=now - timedelta(hours=20))
    never = await _user(session, 2, last_task_digest_at=None)
    await _user(session, 3, last_task_digest_at=now - timedelta(hours=1))  # too soon
    await _user(session, 4, task_digest_enabled=False)  # opted out
    await _user(session, 5, is_banned=True)
    await _user(session, 6, blocked_bot_at=now)
    await _user(session, 7, started_at=None)  # never really started the bot

    due = await due_users(session, settings, now=now)
    assert {user.id for user in due} == {wanted.id, never.id}


@pytest.mark.asyncio
async def test_never_notified_users_come_first(session) -> None:
    settings = _settings()
    now = datetime.now(UTC)
    await _user(session, 1, last_task_digest_at=now - timedelta(hours=30))
    await _user(session, 2, last_task_digest_at=None)
    due = await due_users(session, settings, now=now)
    assert due[0].id == 2


# --- payload -----------------------------------------------------------------------


@pytest.mark.asyncio
async def test_payload_counts_open_tasks_and_campaigns(session) -> None:
    settings = _settings()
    user = await _user(session, 10)
    owner = await _user(session, 11)
    first = await _task(session, "Раз")
    await _task(session, "Два")

    # One task already done must not be counted.
    session.add(UserTask(user_id=user.id, task_id=first.id))
    session.add(
        Campaign(
            owner_id=owner.id,
            kind="channel",
            title="Канал",
            url="https://t.me/promo",
            check_chat="@promo",
            target_count=10,
            done_count=0,
            reward=2,
            xtr_price=30,
            status=CampaignStatus.ACTIVE.value,
        )
    )
    await session.flush()

    payload = await task_digest.build_payload(session, user=user, settings=settings)
    assert payload.tasks == 1
    assert payload.campaigns == 1
    assert payload.total == 2


# --- the runner --------------------------------------------------------------------


class _Recorder:
    def __init__(self) -> None:
        self.sent: list[tuple[int, DigestPayload]] = []

    async def __call__(self, chat_id: int, payload: DigestPayload) -> None:
        self.sent.append((chat_id, payload))


def _runner(factory, sender, settings, **kwargs) -> TaskDigestRunner:
    return TaskDigestRunner(factory, sender=sender, settings=settings, **kwargs)


@pytest.mark.asyncio
async def test_runner_sends_once_per_interval(session_factory) -> None:
    settings = _settings()
    async with session_factory() as db:
        await _user(db, 20)
        await _task(db)
        await db.commit()

    sender = _Recorder()
    runner = _runner(session_factory, sender, settings)

    assert await runner.run_once() == 1
    # Immediately afterwards the same user is no longer due.
    assert await runner.run_once() == 0
    assert [chat_id for chat_id, _ in sender.sent] == [20]

    # ...but once the interval has elapsed they are again.
    later = datetime.now(UTC) + timedelta(hours=13)
    assert await runner.run_once(now=later) == 1


@pytest.mark.asyncio
async def test_runner_is_silent_during_quiet_hours(session_factory) -> None:
    settings = _settings(task_digest_quiet_from=23, task_digest_quiet_to=9)
    async with session_factory() as db:
        await _user(db, 21)
        await _task(db)
        await db.commit()

    sender = _Recorder()
    runner = _runner(session_factory, sender, settings)
    night = datetime(2026, 9, 18, 3, tzinfo=UTC)
    assert await runner.run_once(now=night) == 0
    assert sender.sent == []


@pytest.mark.asyncio
async def test_runner_can_be_switched_off(session_factory) -> None:
    settings = _settings(task_digest_enabled=False)
    async with session_factory() as db:
        await _user(db, 22)
        await _task(db)
        await db.commit()
    sender = _Recorder()
    assert await _runner(session_factory, sender, settings).run_once() == 0


@pytest.mark.asyncio
async def test_nothing_to_offer_means_no_message(session_factory) -> None:
    """A user with no available work must not get an empty nudge."""
    settings = _settings()
    async with session_factory() as db:
        await _user(db, 23)  # no tasks seeded at all
        await db.commit()

    sender = _Recorder()
    runner = _runner(session_factory, sender, settings)
    assert await runner.run_once() == 0
    assert sender.sent == []

    # The user is still stamped, so the empty check is not repeated every tick.
    async with session_factory() as db:
        user = await db.get(User, 23)
        assert user.last_task_digest_at is not None


@pytest.mark.asyncio
async def test_min_tasks_threshold(session_factory) -> None:
    settings = _settings(task_digest_min_tasks=3)
    async with session_factory() as db:
        await _user(db, 24)
        await _task(db, "Одно")
        await db.commit()
    sender = _Recorder()
    assert await _runner(session_factory, sender, settings).run_once() == 0


@pytest.mark.asyncio
async def test_blocked_users_are_marked_and_not_retried(session_factory) -> None:
    settings = _settings()
    async with session_factory() as db:
        await _user(db, 25)
        await _task(db)
        await db.commit()

    async def blocked(chat_id: int, payload: DigestPayload) -> None:
        raise TelegramForbiddenError(method=SendMessage(chat_id=chat_id, text="x"), message="blocked")

    runner = _runner(session_factory, blocked, settings)
    assert await runner.run_once() == 0

    async with session_factory() as db:
        user = await db.get(User, 25)
        assert user.blocked_bot_at is not None

    # They are excluded from the audience from now on.
    async with session_factory() as db:
        assert await due_users(db, settings) == []


@pytest.mark.asyncio
async def test_one_slow_user_does_not_break_the_batch(session_factory) -> None:
    settings = _settings()
    async with session_factory() as db:
        for uid in (30, 31, 32):
            await _user(db, uid)
        await _task(db)
        await db.commit()

    calls: list[int] = []

    async def flaky(chat_id: int, payload: DigestPayload) -> None:
        calls.append(chat_id)
        if chat_id == 31:
            raise RuntimeError("telegram hiccup")

    runner = _runner(session_factory, flaky, settings)
    assert await runner.run_once() == 2
    assert calls == [30, 31, 32]

    # The failed one stays due and will be retried on the next pass.
    async with session_factory() as db:
        assert [u.id for u in await due_users(db, settings)] == [31]


@pytest.mark.asyncio
async def test_shutdown_is_clean_and_idempotent(session_factory) -> None:
    settings = _settings()
    runner = _runner(session_factory, _Recorder(), settings, tick_seconds=1)
    runner.start()
    await runner.shutdown()
    await runner.shutdown()  # must not raise


# --- user-facing toggle ------------------------------------------------------------


@pytest.mark.asyncio(loop_scope="session")
async def test_user_can_opt_out_from_the_profile(harness: BotHarness) -> None:
    h = harness
    await h.reset()
    await h.feed(message_update(USER_ID, "/start"))
    await h.feed(callback_update(USER_ID, "menu:profile"))

    await h.feed(callback_update(USER_ID, "menu:digest:toggle"))
    async with h.factory() as session:
        assert (await session.get(User, USER_ID)).task_digest_enabled is False

    await h.feed(callback_update(USER_ID, "menu:digest:toggle"))
    async with h.factory() as session:
        assert (await session.get(User, USER_ID)).task_digest_enabled is True

    # And the one-tap opt-out from the reminder itself.
    await h.feed(callback_update(USER_ID, "menu:digest:off"))
    async with h.factory() as session:
        assert (await session.get(User, USER_ID)).task_digest_enabled is False


@pytest.mark.asyncio(loop_scope="session")
async def test_reminder_renders_with_the_new_brand(harness: BotHarness) -> None:
    """The digest message is real Telegram output, buttons included."""
    h = harness
    await h.reset()
    await h.feed(message_update(USER_ID, "/start"))
    h.tg.clear()

    await make_digest_sender(h.bot)(USER_ID, DigestPayload(tasks=3, campaigns=2))
    message = h.tg.sent(SendMessage)[-1]
    assert BRAND in message.text or "задания" in message.text.lower()
    labels = [b.text for row in message.reply_markup.inline_keyboard for b in row]
    assert any("3" in label for label in labels)
    assert any("2" in label for label in labels)
    assert any("Не напоминать" in label for label in labels)
