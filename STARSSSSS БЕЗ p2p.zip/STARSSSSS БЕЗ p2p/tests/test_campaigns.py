"""Paid promotion: pricing, the payment → moderation → active flow and payouts."""

from __future__ import annotations

import pytest

from app.config import Settings
from app.db.models import CampaignKind, CampaignStatus, LedgerKind, User
from app.services import campaigns as campaign_service
from app.services import events, ledger
from app.services.errors import AlreadyClaimed, EconomyError, ValidationError


def _settings(**overrides) -> Settings:
    base = {
        "admin_ids_raw": "1",
        "database_url": "sqlite+aiosqlite://",
        "claim_cooldown_seconds": 0,
    }
    return Settings(**{**base, **overrides})


async def _user(session, user_id: int, **fields) -> User:
    user = User(id=user_id, first_name=f"U{user_id}", **fields)
    session.add(user)
    await session.flush()
    return user


async def _paid_campaign(session, owner, settings, **overrides):
    payload = {
        "kind": CampaignKind.CHANNEL.value,
        "title": "Мой канал",
        "description": "Новости",
        "target_raw": "@mychannel",
        "target_count": 10,
    }
    payload.update(overrides)
    campaign = await campaign_service.create_draft(
        session, owner=owner, settings=settings, **payload
    )
    await campaign_service.activate_paid(
        session, campaign=campaign, telegram_charge_id=f"ch-{campaign.id}", settings=settings
    )
    return campaign


# --- pricing ------------------------------------------------------------------------


def test_price_is_completions_times_rate_plus_fee() -> None:
    settings = _settings(
        campaign_reward_channel=2, campaign_xtr_per_reward=1, campaign_service_fee_percent=20
    )
    quote = campaign_service.quote(settings, kind="channel", target_count=100)
    assert quote.reward == 2
    assert quote.payout == 200
    assert quote.price_xtr == 240  # 200 × 1.20

    no_fee = _settings(campaign_reward_bot=3, campaign_service_fee_percent=0)
    assert campaign_service.quote(no_fee, kind="bot", target_count=50).price_xtr == 150


def test_target_count_bounds_are_enforced() -> None:
    settings = _settings(campaign_min_target=10, campaign_max_target=1000)
    for bad in (0, 9, 1001):
        with pytest.raises(ValidationError):
            campaign_service.quote(settings, kind="channel", target_count=bad)
    with pytest.raises(ValidationError):
        campaign_service.quote(settings, kind="nonsense", target_count=100)


def test_target_parsing_per_kind() -> None:
    url, chat = campaign_service.parse_target("channel", "@kodo")
    assert url == "https://t.me/kodo" and chat == "@kodo"

    url, chat = campaign_service.parse_target("bot", "@mybot")
    assert url == "https://t.me/mybot" and chat is None

    url, chat = campaign_service.parse_target("post", "https://t.me/kodo/12")
    assert url == "https://t.me/kodo/12" and chat is None

    for kind, bad in (("channel", "kodo"), ("bot", "ftp://x"), ("custom", "not-a-url"), ("post", "")):
        with pytest.raises(ValidationError):
            campaign_service.parse_target(kind, bad)


def test_title_and_description_normalisation() -> None:
    assert campaign_service.normalize_title("  Мой   канал  ") == "Мой канал"
    with pytest.raises(ValidationError):
        campaign_service.normalize_title("ab")
    assert campaign_service.normalize_description("-") == ""
    assert len(campaign_service.normalize_description("x" * 500)) == 300


# --- lifecycle ----------------------------------------------------------------------


@pytest.mark.asyncio
async def test_payment_sends_campaign_to_moderation(session) -> None:
    settings = _settings(campaign_moderation=True)
    owner = await _user(session, 1001)
    campaign = await campaign_service.create_draft(
        session,
        owner=owner,
        kind=CampaignKind.CHANNEL.value,
        title="Мой канал",
        description="",
        target_raw="@kodo",
        target_count=10,
        settings=settings,
    )
    assert campaign.status == CampaignStatus.AWAITING_PAYMENT.value
    assert campaign.xtr_price == settings.campaign_price("channel", 10)

    assert (
        await campaign_service.activate_paid(
            session, campaign=campaign, telegram_charge_id="ch-1", settings=settings
        )
        is True
    )
    assert campaign.status == CampaignStatus.MODERATION.value
    assert {event.name for event in events.peek(session)} == {"campaign_moderation"}

    # Telegram redelivery of the same charge changes nothing.
    assert (
        await campaign_service.activate_paid(
            session, campaign=campaign, telegram_charge_id="ch-1", settings=settings
        )
        is False
    )


@pytest.mark.asyncio
async def test_moderation_off_activates_immediately(session) -> None:
    settings = _settings(campaign_moderation=False)
    owner = await _user(session, 1002)
    campaign = await _paid_campaign(session, owner, settings)
    assert campaign.status == CampaignStatus.ACTIVE.value


@pytest.mark.asyncio
async def test_approve_and_reject(session) -> None:
    settings = _settings(campaign_moderation=True)
    owner = await _user(session, 1003)

    approved = await _paid_campaign(session, owner, settings)
    await campaign_service.approve(session, campaign=approved, admin_id=1)
    assert approved.status == CampaignStatus.ACTIVE.value
    with pytest.raises(ValidationError):
        await campaign_service.approve(session, campaign=approved, admin_id=1)

    rejected = await _paid_campaign(session, owner, settings, title="Второй канал")
    await campaign_service.reject(session, campaign=rejected, admin_id=1, reason="Запрещённая тематика")
    assert rejected.status == CampaignStatus.REJECTED.value
    assert rejected.moderation_note == "Запрещённая тематика"


@pytest.mark.asyncio
async def test_active_campaign_limit_per_user(session) -> None:
    settings = _settings(campaign_moderation=False, campaign_max_active_per_user=2)
    owner = await _user(session, 1004)
    for index in range(2):
        await _paid_campaign(session, owner, settings, title=f"Канал {index}")
    with pytest.raises(ValidationError):
        await campaign_service.create_draft(
            session,
            owner=owner,
            kind=CampaignKind.CHANNEL.value,
            title="Третий",
            description="",
            target_raw="@kodo",
            target_count=10,
            settings=settings,
        )


# --- performing -----------------------------------------------------------------------


@pytest.mark.asyncio
async def test_completion_pays_performer_and_burns_budget(session) -> None:
    settings = _settings(campaign_moderation=False, campaign_reward_channel=2)
    owner = await _user(session, 1005)
    campaign = await _paid_campaign(session, owner, settings, target_count=10)

    async def member(chat: str) -> bool:
        return True

    performer = await _user(session, 1006)
    amount = await campaign_service.complete(
        session, user=performer, campaign=campaign, settings=settings, membership_checker=member
    )
    assert amount == 2
    assert campaign.done_count == 1
    assert await ledger.get_balance(session, performer.id) == 2
    entries = await ledger.history(session, performer.id)
    assert entries[0].kind == LedgerKind.PROMO_TASK.value

    with pytest.raises(AlreadyClaimed):
        await campaign_service.complete(
            session, user=performer, campaign=campaign, settings=settings, membership_checker=member
        )


@pytest.mark.asyncio
async def test_unsubscribed_performer_is_not_paid(session) -> None:
    settings = _settings(campaign_moderation=False)
    owner = await _user(session, 1007)
    campaign = await _paid_campaign(session, owner, settings)
    performer = await _user(session, 1008)

    async def not_member(chat: str) -> bool:
        return False

    with pytest.raises(EconomyError):
        await campaign_service.complete(
            session,
            user=performer,
            campaign=campaign,
            settings=settings,
            membership_checker=not_member,
        )
    assert campaign.done_count == 0
    assert await ledger.get_balance(session, performer.id) == 0


@pytest.mark.asyncio
async def test_budget_cannot_be_oversold_and_campaign_finishes(session) -> None:
    settings = _settings(campaign_moderation=False, campaign_min_target=1, campaign_reward_post=1)
    owner = await _user(session, 1009)
    campaign = await _paid_campaign(
        session,
        owner,
        settings,
        kind=CampaignKind.POST.value,
        target_raw="https://t.me/kodo/1",
        target_count=2,
    )
    for user_id in (1010, 1011):
        performer = await _user(session, user_id)
        await campaign_service.complete(
            session, user=performer, campaign=campaign, settings=settings
        )
    assert campaign.done_count == 2
    assert campaign.status == CampaignStatus.DONE.value

    late = await _user(session, 1012)
    with pytest.raises(EconomyError):
        await campaign_service.complete(session, user=late, campaign=campaign, settings=settings)


@pytest.mark.asyncio
async def test_owner_cannot_perform_own_campaign(session) -> None:
    settings = _settings(campaign_moderation=False)
    owner = await _user(session, 1013)
    campaign = await _paid_campaign(session, owner, settings)
    with pytest.raises(EconomyError):
        await campaign_service.complete(session, user=owner, campaign=campaign, settings=settings)


@pytest.mark.asyncio
async def test_listing_hides_own_done_and_paused_campaigns(session) -> None:
    settings = _settings(campaign_moderation=False, campaign_min_target=1)
    owner = await _user(session, 1014)
    performer = await _user(session, 1015)

    mine = await _paid_campaign(session, owner, settings, title="Свой")
    other_owner = await _user(session, 1016)
    theirs = await _paid_campaign(session, other_owner, settings, title="Чужой")
    paused = await _paid_campaign(session, other_owner, settings, title="Пауза")
    await campaign_service.set_paused(session, campaign=paused, paused=True)

    # Paused campaigns are hidden from everyone.
    available = await campaign_service.list_available(session, user=performer, settings=settings)
    assert {c.id for c in available} == {mine.id, theirs.id}

    # An owner never sees their own campaign in the task list.
    for_owner = await campaign_service.list_available(session, user=owner, settings=settings)
    assert {c.id for c in for_owner} == {theirs.id}

    async def member(chat: str) -> bool:
        return True

    # A campaign the performer already did drops out of their list.
    await campaign_service.complete(
        session, user=performer, campaign=theirs, settings=settings, membership_checker=member
    )
    left = await campaign_service.list_available(session, user=performer, settings=settings)
    assert {c.id for c in left} == {mine.id}


@pytest.mark.asyncio
async def test_promotion_can_be_switched_off(session) -> None:
    settings = _settings(promo_campaigns_enabled=False)
    owner = await _user(session, 1017)
    with pytest.raises(EconomyError):
        await campaign_service.create_draft(
            session,
            owner=owner,
            kind=CampaignKind.CHANNEL.value,
            title="Канал",
            description="",
            target_raw="@kodo",
            target_count=10,
            settings=settings,
        )
    performer = await _user(session, 1018)
    assert await campaign_service.list_available(session, user=performer, settings=settings) == []


@pytest.mark.asyncio
async def test_stats_report(session) -> None:
    settings = _settings(campaign_moderation=True)
    owner = await _user(session, 1019)
    await _paid_campaign(session, owner, settings)
    stats = await campaign_service.stats(session)
    assert stats["total"] == 1
    assert stats["moderation"] == 1
    assert stats["revenue_xtr"] == settings.campaign_price("channel", 10)
