"""Startup must never hang and must always answer the panel's Stop button.

Two real defects are guarded here:

1. When the bot could not start (bad/placeholder ``BOT_TOKEN``) the process parked
   on a bare ``asyncio.Event().wait()``. On that path nothing had installed signal
   handlers, so asyncio's running loop swallowed SIGTERM and the process could only
   be killed with SIGKILL — the hosting panel's Stop/Restart did nothing and the
   app looked frozen.
2. The startup ``get_me()`` / ``set_my_commands()`` calls were unbounded. aiogram's
   default session timeout is 60 s and it retries, so a blocked outbound connection
   turned boot into a multi-minute silent freeze with no log line.
"""

from __future__ import annotations

import asyncio
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import pytest
import structlog

from app.__main__ import idle_until_signal
from app.config import Settings

REPO_ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.asyncio
async def test_idle_until_signal_returns_on_sigterm() -> None:
    """The idle wait must end when the process is asked to stop."""
    log = structlog.get_logger("test")
    task = asyncio.create_task(idle_until_signal(log))
    await asyncio.sleep(0.05)  # let the handlers install
    assert not task.done()

    os.kill(os.getpid(), signal.SIGTERM)
    await asyncio.wait_for(task, timeout=5)


@pytest.mark.asyncio
async def test_idle_until_signal_restores_handlers() -> None:
    """Handlers are removed afterwards so later code sees a clean loop."""
    loop = asyncio.get_running_loop()
    task = asyncio.create_task(idle_until_signal(structlog.get_logger("test")))
    await asyncio.sleep(0.05)
    os.kill(os.getpid(), signal.SIGINT)
    await asyncio.wait_for(task, timeout=5)

    # Re-installing must not raise: the previous handlers are gone.
    loop.add_signal_handler(signal.SIGTERM, lambda: None)
    loop.remove_signal_handler(signal.SIGTERM)


@pytest.mark.asyncio
async def test_startup_api_calls_are_bounded() -> None:
    """A Telegram API call that never answers must not stall the boot sequence."""
    settings = Settings(
        admin_ids_raw="1",
        database_url="sqlite+aiosqlite://",
        startup_api_timeout_sec=0.2,
    )

    async def never_answers() -> None:
        await asyncio.sleep(3600)

    started = time.monotonic()
    with pytest.raises(TimeoutError):
        await asyncio.wait_for(never_answers(), timeout=settings.startup_api_timeout_sec)
    assert time.monotonic() - started < 5


def test_startup_timeout_is_configurable() -> None:
    assert Settings(admin_ids_raw="1", database_url="sqlite+aiosqlite://").startup_api_timeout_sec > 0
    custom = Settings(
        admin_ids_raw="1", database_url="sqlite+aiosqlite://", startup_api_timeout_sec=3
    )
    assert custom.startup_api_timeout_sec == 3


@pytest.mark.slow
def test_process_stops_on_sigterm_with_a_placeholder_token() -> None:
    """End to end: boot the real entrypoint, then press «Stop».

    This is the exact scenario reported as «main завис на запуске»: with an
    unusable token the process idles forever, and before the fix SIGTERM was
    ignored, so the panel could never restart it.
    """
    with tempfile.TemporaryDirectory() as tmp:
        env = {
            **os.environ,
            "DATABASE_URL": f"sqlite+aiosqlite:///{Path(tmp) / 'bot.db'}",
            "ADMIN_IDS": "1",
            "PYTHONPATH": str(REPO_ROOT),
            "PYTHONUNBUFFERED": "1",
        }
        env.pop("BOT_TOKEN", None)  # placeholder path
        proc = subprocess.Popen(
            [sys.executable, "-u", "main.py"],
            cwd=REPO_ROOT,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        captured: list[str] = []
        reader = threading.Thread(target=_drain, args=(proc, captured), daemon=True)
        reader.start()
        try:
            # Wait for the process to actually reach the idle state it used to hang in.
            deadline = time.monotonic() + 90
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    pytest.fail("process exited early:\n" + "".join(captured))
                if any("idle_after_placeholder_token" in line for line in captured):
                    break
                time.sleep(0.25)
            else:
                pytest.fail("process never reached the idle state:\n" + "".join(captured))

            proc.send_signal(signal.SIGTERM)
            try:
                proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                proc.kill()
                pytest.fail("SIGTERM ignored: the process had to be killed")
            assert any("stopped_by_signal" in line for line in captured), "".join(captured)
        finally:
            if proc.poll() is None:
                proc.kill()
            proc.wait(timeout=10)


def _drain(proc: subprocess.Popen, sink: list[str]) -> None:
    """Consume the child's output so it never blocks on a full pipe."""
    assert proc.stdout is not None
    for line in proc.stdout:
        sink.append(line)
